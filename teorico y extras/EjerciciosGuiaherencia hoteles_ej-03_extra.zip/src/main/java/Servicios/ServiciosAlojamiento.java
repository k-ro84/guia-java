package Servicios;

import Entidades.Camping;
import Entidades.Hotel3estrellas;
import Entidades.Hotel4estrellas;
import Entidades.Hotel5estrellas;
import Entidades.Residencia;
import Enumeraciones.TipoAlojamiento;
import Superclases.Alojamiento;
import Superclases.Hotel;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.TreeSet;

/**
 * @author MandraKeeTo Sebastián Encina 3dProDesign Enterprise
 * creaciones3dpro@gmail.com.ar
 */
public class ServiciosAlojamiento {

    ArrayList<Alojamiento> listaAlojamientos;

    public ServiciosAlojamiento() throws IOException {
        listaAlojamientos = new ArrayList<>();
        precargarAlojamientos();
        menuOpciones();
    }

    Scanner sc = new Scanner(System.in).useDelimiter("\n");

    private void menuOpciones() throws IOException {
        char op;
        do {
            System.out.println("--------------------------------------------------------");
            System.out.println("   * * *  MENU OPCIONES / RESERVA DE ALOJAMIENTOS  * * *");
            System.out.println("--------------------------------------------------------");
            System.out.println("                 > Menu de Opciones <");
            System.out.println("");
            System.out.println("      < A > Ver lista de alojamientos registrados.");
            System.out.println("      < B > Ver hoteles de más caro a más barato.");
            System.out.println("      < C > Ver lista de campings con restaurante.");
            System.out.println("      < D > Ver lista de residencias con descuento.");
            System.out.println("      < E > Agregar nuevo alojamiento.");
            System.out.println("");
            System.out.println("      < F > Terminar programa.");
            System.out.println("");
            System.out.println("-------------------------------------------------------");
            System.out.println(" ... ingresa una opción ...");
            op = Character.toUpperCase(sc.next().charAt(0));
            switch (op) {
                case 'A':
                    verRegistroDeAlojamientos();
                    break;
                case 'B':
                    verHotelesCaroABaratos();
                    break;
                case 'C':
                    verCampingsConRestaurante();
                    break;
                case 'D':
                    verResidenciasConDescuento();
                    break;
                case 'E':
                    agregarAlojamientos();
                    break;
                case 'F':
                    break;
                default:
                    System.out.println("  ... ingreso no válido... REINTENTE !!");
            }
            System.out.println("----------------------------------------------------");
            if (op != 'F') {
                System.out.println("   ... presione < enter > para continuar !!");
                System.in.read();
            }
        } while (op != 'F');

        System.out.println("PROGRAMA TERMINADO");
    }

    private void verRegistroDeAlojamientos() {
        System.out.println("");
        System.out.println("    **** REGISTRO DE ALOJAMIENTOS ****");
        System.out.println("===========================================");
        listaAlojamientos.forEach(aux -> {
            aux.mostrarDetalles();
            System.out.println("");
            System.out.println("------------------------------------------------------------");
        });
    }

    private void verHotelesCaroABaratos() {
        TreeSet<Hotel> listaHoteles = new TreeSet<>();
        for (Alojamiento aux : listaAlojamientos) {
            if (aux instanceof Hotel) {
                Hotel x = (Hotel) aux;
                listaHoteles.add(x);
            }
        }

        System.out.println("");
        System.out.println("    **** HOTELES MÁS CARO A BARATO ****");
        System.out.println("===========================================");
        for (Hotel hotel : listaHoteles) {
            //System.out.println(hotel.getCategoria() + " / Precio Habitación: ($) " + hotel.getPrecioHabitacion() + " / " + hotel.getNombre());
            hotel.mostrarDetalles();
            System.out.println("");
            System.out.println("------------------------------------------------------------");
        }
    }

    private void verCampingsConRestaurante() {
        System.out.println("");
        System.out.println("    **** CAMPINGS CON RESTAURANTE ****");
        System.out.println("===========================================");
        for (Alojamiento aux : listaAlojamientos) {
            if (aux instanceof Camping) {
                Camping x = (Camping) aux;
                if (x.isRestaurante()) {
                    //System.out.println(x);
                    x.mostrarDetalles();
                    System.out.println("");
                    System.out.println("------------------------------------------------------------");
                }
            }
        }
    }

    private void verResidenciasConDescuento() {
        System.out.println("");
        System.out.println("    **** RESIDENCIAS CON DESCUENTO ****");
        System.out.println("===========================================");
        for (Alojamiento aux : listaAlojamientos) {
            if (aux instanceof Residencia) {
                Residencia x = (Residencia) aux;
                if (x.isDescuentosGremiales()) {
                    //System.out.println(x);
                    x.mostrarDetalles();
                    System.out.println("");
                    System.out.println("------------------------------------------------------------");
                }
            }
        }
    }

    private void agregarAlojamientos() {
        int op;
        int i;
        char rpta;
        do {
            rpta = 'N';
            do {
                Alojamiento alojamiento = null;
                i = 1;
                System.out.println("Ingrese el tipo de alojamiento a registrar:");
                for (TipoAlojamiento tipo : TipoAlojamiento.values()) {
                    System.out.println("< " + i + " > " + tipo.getDescripcion());
                    i++;
                }
                System.out.println("");
                System.out.println("Ingrese 0 para finalizar:");
                op = sc.nextInt();
                switch (op) {
                    case 1:
                        alojamiento = new Hotel3estrellas();
                        break;
                    case 2:
                        alojamiento = new Hotel4estrellas();
                        break;
                    case 3:
                        alojamiento = new Hotel5estrellas();
                        break;
                    case 4:
                        alojamiento = new Camping();
                        break;
                    case 5:
                        alojamiento = new Residencia();
                        break;
                    case 0:
                        break;
                    default:
                        System.out.println(" ... opción no válida... REINTENTE !");
                }
                if (op >= 1 && op <= 5) {
                    alojamiento.crearAlojamiento();
                    alojamiento.calcularPrecioHabitacion();
                    listaAlojamientos.add(alojamiento);
                    alojamiento = null;
                }
            } while (op < 0 || op > 5);
            if (op > 0) {
                System.out.println("");
                rpta = pregunta("Desea seguir agregando alojamientos ? ( s/n )");
            }
        } while (rpta == 'S');
    }

    private void precargarAlojamientos() {
// Hotel3estrellas(String nombre, String direccion, String localidad, String nombreGerente, TipoAlojamiento tipoAlojamiento, Integer cantPisosHotel, Integer cantHabitaciones, Integer cantCamasXhabitacion, boolean salaEstar, boolean patioInterno, boolean banioPrivado)
// Hotel4estrellas(String nombre, String direccion, String localidad, String nombreGerente, TipoAlojamiento tipoAlojamiento, Integer cantPisosHotel, Integer cantHabitaciones, Integer cantCamasXhabitacion, String nombreRestaurante, Integer capacidadRestaurante, char categoriaGimnasio)
// Hotel5estrellas(String nombre, String direccion, String localidad, String nombreGerente, TipoAlojamiento tipoAlojamiento, Integer cantPisosHotel, Integer cantHabitaciones, Integer cantCamasXhabitacion, String nombreRestaurante, Integer capacidadRestaurante, char categoriaGimnasio, Integer cantSalasConferencia, Integer cantSuites, Integer cantLimosnas)
        System.out.println("   ... creando Hoteles ...");
        listaAlojamientos.add(new Hotel3estrellas("Alforjas Doradas", "Santos Domingos 1475", "Besares de América", "Osvaldo Laport", TipoAlojamiento.ALOJAMIENTO_H3, 3, 5, 2, true, true, false));
        listaAlojamientos.add(new Hotel3estrellas("Elements of Life", "Av. Suipacha 4519", "Bonanza", "Mariano Moreno", TipoAlojamiento.ALOJAMIENTO_H3, 2, 7, 2, false, true, false));
        listaAlojamientos.add(new Hotel4estrellas("Lamento Boliviano", "Av. Besares 1125", "Nuñez", "Esteban Gonzales", TipoAlojamiento.ALOJAMIENTO_H4, 3, 9, 3, "Bon a Petit", 50, 'A'));
        listaAlojamientos.add(new Hotel4estrellas("Despertares", "Rocafeller 3216", "Bermejo", "Darío Grandinetti", TipoAlojamiento.ALOJAMIENTO_H4, 4, 6, 3, "Manjares", 65, 'B'));
        listaAlojamientos.add(new Hotel5estrellas("Amanecer", "Av. Cabildo 312", "Gutierrez", "Rodolfo Peralta", TipoAlojamiento.ALOJAMIENTO_H5, 7, 10, 3, "Sin Piedad", 90, 'A', 1, 2, 500));
        listaAlojamientos.add(new Hotel5estrellas("Ven a mi", "San Martín 2758", "Mendoza", "Santiago cafiero", TipoAlojamiento.ALOJAMIENTO_H5, 14, 9, 4, "Estrategia Culinaria", 400, 'A', 3, 10, 2300));
// Camping(String nombre, String direccion, String localidad, String nombreGerente, TipoAlojamiento tipoAlojamiento, boolean privado, Integer metrosCuadrados, Integer capacidadCarpas, Integer cantBanios, boolean restaurante)
// Residencia(String nombre, String direccion, String localidad, String nombreGerente, TipoAlojamiento tipoAlojamiento, boolean privado, Integer metrosCuadrados, Integer cantHabitaciones, boolean campoDeportivo, boolean descuentosGremiales) {
        System.out.println("   ... creando Campamentos ...");
        listaAlojamientos.add(new Camping("Primavera", "Cabildo 125", "Maipú", "Javier Sanchez", TipoAlojamiento.ALOJAMIENTO_CA, true, 2000, 100, 1, false));
        listaAlojamientos.add(new Camping("El Nihuil", "Av. Vallecitos 729", "Las Heras", "Diego Peralta", TipoAlojamiento.ALOJAMIENTO_CA, false, 4200, 210, 2, true));
        listaAlojamientos.add(new Camping("La Ranchera", "Calle s/n", "Papagallos", "Daniel Francisconni", TipoAlojamiento.ALOJAMIENTO_CA, true, 1500, 50, 3, true));
        System.out.println("   ... creando Residencias ...");
        listaAlojamientos.add(new Residencia("Los Abuelos", "Av. Libertad 540", "Guaymallén", "Rodrigo Perez", TipoAlojamiento.ALOJAMIENTO_RE, false, 400, 20, false, true));
        listaAlojamientos.add(new Residencia("Pacifico", "Av. Los Lamentos 415", "Dorrego", "Germán Robledo", TipoAlojamiento.ALOJAMIENTO_RE, false, 500, 30, false, false));
        listaAlojamientos.add(new Residencia("Estancia Mendoza", "Los  Ciruelos 4890", "Maipú", "Francisco Sanchez", TipoAlojamiento.ALOJAMIENTO_RE, true, 800, 30, true, true));
        System.out.println("   ... calculando precios de habitaciones ...");
        for (Alojamiento alojamiento : listaAlojamientos) {
            alojamiento.calcularPrecioHabitacion();
        }
    }

    private char pregunta(String pregunta) {
        char rpta = 'N';
        System.out.println(pregunta);
        do {
            rpta = Character.toUpperCase(sc.next().charAt(0));
            if (rpta != 'S' && rpta != 'N') {
                System.out.println("Ingrese una opción válida !");
            }
        } while (rpta != 'S' && rpta != 'N');
        return rpta;
    }
}
