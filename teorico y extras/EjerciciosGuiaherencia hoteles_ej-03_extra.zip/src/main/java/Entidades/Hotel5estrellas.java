package Entidades;

import Enumeraciones.TipoAlojamiento;

/**
 * @author MandraKeeTo Sebastián Encina 3dProDesign Enterprise
 * creaciones3dpro@gmail.com.ar
 */
public final class Hotel5estrellas extends Hotel4estrellas {

    protected Integer cantSalasConferencia;
    protected Integer cantSuites;
    protected Integer cantLimosnas;

    public Hotel5estrellas() {
        super();
        this.tipoAlojamiento = TipoAlojamiento.ALOJAMIENTO_H5;
    }

    public Hotel5estrellas(String nombre, String direccion, String localidad, String nombreGerente, TipoAlojamiento tipoAlojamiento, Integer cantPisosHotel, Integer cantHabitaciones, Integer cantCamasXhabitacion, String nombreRestaurante, Integer capacidadRestaurante, char categoriaGimnasio, Integer cantSalasConferencia, Integer cantSuites, Integer cantLimosnas) {
        super(nombre, direccion, localidad, nombreGerente, tipoAlojamiento, cantPisosHotel, cantHabitaciones, cantCamasXhabitacion, nombreRestaurante, capacidadRestaurante, categoriaGimnasio);
        this.cantSalasConferencia = cantSalasConferencia;
        this.cantSuites = cantSuites;
        this.cantLimosnas = cantLimosnas;
    }

    public Integer getCantSalasConferencia() {
        return cantSalasConferencia;
    }

    public Integer getCantSuites() {
        return cantSuites;
    }

    public Integer getCantLimosnas() {
        return cantLimosnas;
    }

    @Override
    public void crearAlojamiento() {
        super.crearAlojamiento();
        System.out.println("Ingrese la cantidad de salas de conferencia:");
        this.cantSalasConferencia = sc.nextInt();
        System.out.println("Ingrese la cantidad de suites:");
        this.cantSuites = sc.nextInt();
        System.out.println("Ingrese la cantidad de limosnas recibidas:");
        this.cantLimosnas = sc.nextInt();
    }

    private Integer valorAgregado() {
        Integer valorAgregado = 0;
        valorAgregado += 5 * cantSalasConferencia;
        valorAgregado += 10 * cantSuites;
        valorAgregado += 15 * cantLimosnas;
        return valorAgregado;
    }

    @Override
    public void calcularPrecioHabitacion() {
        super.calcularPrecioHabitacion();
        this.precioHabitacion += valorAgregado();
        System.out.println("Precio habitación: " + this.precioHabitacion);
    }

    @Override
    public String toString() {
        return "Hotel5estrellas{" + "cantSalasConferencia=" + cantSalasConferencia + ", cantSuites=" + cantSuites + ", cantLimosnas=" + cantLimosnas + '}';
    }

    @Override
    public void mostrarDetalles() {
        super.mostrarDetalles();
        System.out.println(" ->");
        System.out.println("    * posee sala de conferencias: true / cantidad: " + cantSalasConferencia);
        System.out.println("    * posee suites: true / cantidad: " + cantSuites);
        System.out.println("    * acepta limosnas: true / cantidad: " + cantLimosnas);
    }
}
