package Entidades;

import Enumeraciones.TipoAlojamiento;
import Superclases.Hotel;

/**
 * @author MandraKeeTo Sebastián Encina 3dProDesign Enterprise
 * creaciones3dpro@gmail.com.ar
 */
public class Hotel3estrellas extends Hotel {

    protected boolean salaEstar;
    protected boolean patioInterno;
    protected boolean banioPrivado;

    public Hotel3estrellas() {
        super();
        this.tipoAlojamiento = TipoAlojamiento.ALOJAMIENTO_H3;
    }

    public Hotel3estrellas(String nombre, String direccion, String localidad, String nombreGerente, TipoAlojamiento tipoAlojamiento, Integer cantPisosHotel, Integer cantHabitaciones, Integer cantCamasXhabitacion, boolean salaEstar, boolean patioInterno, boolean banioPrivado) {
        super(nombre, direccion, localidad, nombreGerente, tipoAlojamiento, cantPisosHotel, cantHabitaciones, cantCamasXhabitacion);
        this.salaEstar = salaEstar;
        this.patioInterno = patioInterno;
        this.banioPrivado = banioPrivado;
    }

    public boolean isSalaEstar() {
        return salaEstar;
    }

    public boolean isPatioInterno() {
        return patioInterno;
    }

    public boolean isBanioPrivado() {
        return banioPrivado;
    }

    @Override
    public void crearAlojamiento() {
        super.crearAlojamiento();
        if (!this.tipoAlojamiento.equals(this.tipoAlojamiento.ALOJAMIENTO_H3)) {
            salaEstar = true;
            patioInterno = true;
            banioPrivado = true;
        } else {
            char rpta = pregunta("El hotel posee sala de estar para recibir visitas ? ( s/n )");
            salaEstar = (rpta == 'S');
            rpta = pregunta("EL hotel posee patio interno para relajarse ? ( s/n )");
            patioInterno = (rpta == 'S');
            rpta = pregunta("El hotel posee baño privado en las habitaciones ? ( s/n )");
            banioPrivado = (rpta == 'S');
        }

    }

    private Integer valorAgregado() {
        Integer valorAgregado = 0;

        if (salaEstar) {
            valorAgregado += 10;
        }
        if (patioInterno) {
            valorAgregado += 20;
        }
        if (banioPrivado) {
            valorAgregado += +30;
        }
        return valorAgregado;
    }

    @Override
    public void calcularPrecioHabitacion() {
        super.calcularPrecioHabitacion();
        this.precioHabitacion += valorAgregado();
        System.out.println("Precio habitación: " + this.precioHabitacion);
    }

    @Override
    public String toString() {
        return "Hotel3estrellas{" + "salaEstar=" + salaEstar + ", patioInterno=" + patioInterno + ", banioPrivado=" + banioPrivado + '}';
    }

    @Override
    public void mostrarDetalles() {
        super.mostrarDetalles();
        System.out.println(" ->");
        System.out.println("    * posee sala de estar: " + salaEstar);
        System.out.println("    * posee patio interno: " + patioInterno);
        System.out.println("    * posee baño privado: " + banioPrivado);
    }
}
