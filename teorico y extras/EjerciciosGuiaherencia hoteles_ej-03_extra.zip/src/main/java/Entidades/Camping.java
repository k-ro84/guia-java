package Entidades;

import Enumeraciones.TipoAlojamiento;
import Superclases.Extrahotelero;

/**
 * @author MandraKeeTo Sebastián Encina 3dProDesign Enterprise
 * creaciones3dpro@gmail.com.ar
 */
public class Camping extends Extrahotelero {

    protected Integer capacidadCarpas;
    protected Integer cantBanios;
    protected boolean restaurante;

    public Camping() {
        super();
        this.tipoAlojamiento = TipoAlojamiento.ALOJAMIENTO_CA;
    }

    public Camping(String nombre, String direccion, String localidad, String nombreGerente, TipoAlojamiento tipoAlojamiento, boolean privado, Integer metrosCuadrados, Integer capacidadCarpas, Integer cantBanios, boolean restaurante) {
        super(nombre, direccion, localidad, nombreGerente, tipoAlojamiento, privado, metrosCuadrados);
        this.capacidadCarpas = capacidadCarpas;
        this.cantBanios = cantBanios;
        this.restaurante = restaurante;
    }

    public Integer getCapacidadCarpas() {
        return capacidadCarpas;
    }

    public Integer getCantBanios() {
        return cantBanios;
    }

    public boolean isRestaurante() {
        return restaurante;
    }

    @Override
    public void crearAlojamiento() {
        super.crearAlojamiento();
        System.out.println("Indique la capacidad máxima de carpas que posee el recinto:");
        this.capacidadCarpas = sc.nextInt();
        System.out.println("Indique la cantidad de baños que posee el recinto:");
        this.cantBanios = sc.nextInt();
        char rpta = pregunta("El alojamiento posee restaurante ? ( s/n )");
        restaurante = (rpta == 'S');
    }

    @Override
    public void calcularPrecioHabitacion() {

    }

    @Override
    public String toString() {
        return "Camping{" + "capacidadCarpas=" + capacidadCarpas + ", cantBanios=" + cantBanios + ", restaurante=" + restaurante + '}';
    }

    @Override
    public void mostrarDetalles() {
        super.mostrarDetalles();
        System.out.println(" ->");
        System.out.println("    * posee restaurante: " + restaurante);
        System.out.println("    * capacidad de carpas: " + capacidadCarpas);
        System.out.println("    * baños: " + cantBanios);
    }
}
