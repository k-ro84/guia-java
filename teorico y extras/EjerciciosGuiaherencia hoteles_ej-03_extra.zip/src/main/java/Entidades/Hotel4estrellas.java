package Entidades;

import Enumeraciones.TipoAlojamiento;

/**
 * @author MandraKeeTo Sebastián Encina 3dProDesign Enterprise
 * creaciones3dpro@gmail.com.ar
 */
public class Hotel4estrellas extends Hotel3estrellas {

    protected String nombreRestaurante;
    protected Integer capacidadRestaurante;
    protected char categoriaGimnasio;

    public Hotel4estrellas() {
        super();
        this.tipoAlojamiento = TipoAlojamiento.ALOJAMIENTO_H4;
    }

    public Hotel4estrellas(String nombre, String direccion, String localidad, String nombreGerente, TipoAlojamiento tipoAlojamiento, Integer cantPisosHotel, Integer cantHabitaciones, Integer cantCamasXhabitacion, String nombreRestaurante, Integer capacidadRestaurante, char categoriaGimnasio) {
        super(nombre, direccion, localidad, nombreGerente, tipoAlojamiento, cantPisosHotel, cantHabitaciones, cantCamasXhabitacion, true, true, true);
        this.nombreRestaurante = nombreRestaurante;
        this.capacidadRestaurante = capacidadRestaurante;
        this.categoriaGimnasio = categoriaGimnasio;
    }

    public String getNombreRestaurante() {
        return nombreRestaurante;
    }

    public Integer getCapacidadRestaurante() {
        return capacidadRestaurante;
    }

    public char getCategoriaGimnasio() {
        return categoriaGimnasio;
    }

    @Override
    public void crearAlojamiento() {
        super.crearAlojamiento();
        System.out.println("Ingrese el nombre del restaurante:");
        this.nombreRestaurante = sc.next();
        System.out.println("Ingrese la capacidad de comensales del restaurante:");
        System.out.println("          -- < 30 / 30 a 50 / > 50 --");
        this.capacidadRestaurante = sc.nextInt();
        char cat;
        do {
            System.out.println("Indique la categoría del gimnasio: ( A/B )");
            cat = Character.toUpperCase(sc.next().charAt(0));
            if (cat != 'A' && cat != 'B') {
                System.out.println("   ... entrada no válida... REINTENTE !!");
            }
        } while (cat != 'A' && cat != 'B');
        this.categoriaGimnasio = cat;

    }

    private Integer valorAgregadoRestaurante() {
        Integer valorAgregado;
        if (capacidadRestaurante < 30) {
            valorAgregado = 10;
        } else if (capacidadRestaurante >= 30 && capacidadRestaurante <= 50) {
            valorAgregado = 30;
        } else {
            valorAgregado = 50;
        }

        return valorAgregado;
    }

    private Integer valorAgregadoGimnasio() {
        Integer valorAgregado = 0;
        switch (categoriaGimnasio) {
            case 'A':
                valorAgregado = 50;
                break;
            case 'B':
                valorAgregado = 30;
                break;
        }
        return valorAgregado;
    }

    @Override
    public void calcularPrecioHabitacion() {
        super.calcularPrecioHabitacion();
        this.precioHabitacion += valorAgregadoRestaurante() + valorAgregadoGimnasio();
        System.out.println("Precio habitación: " + this.precioHabitacion);
    }

    @Override
    public String toString() {
        return "Hotel4estrellas{" + "nombreRestaurante=" + nombreRestaurante + ", capacidadRestaurante=" + capacidadRestaurante + ", categoriaGimnasio=" + categoriaGimnasio + '}';
    }

    @Override
    public void mostrarDetalles() {
        super.mostrarDetalles();
        System.out.println(" ->");
        System.out.println("    * posee restaurante: true / capacidad: " + capacidadRestaurante);
        System.out.println("    * posee gimnasio: true / categoría: " + categoriaGimnasio);
    }
}
