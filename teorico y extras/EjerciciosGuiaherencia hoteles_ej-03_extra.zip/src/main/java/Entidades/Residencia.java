package Entidades;

import Enumeraciones.TipoAlojamiento;
import Superclases.Extrahotelero;

/**
 * @author MandraKeeTo Sebastián Encina 3dProDesign Enterprise
 * creaciones3dpro@gmail.com.ar
 */
public class Residencia extends Extrahotelero {

    protected Integer cantHabitaciones;
    protected boolean campoDeportivo;
    protected boolean descuentosGremiales;

    public Residencia() {
        super();
        this.tipoAlojamiento = TipoAlojamiento.ALOJAMIENTO_RE;
    }

    public Residencia(String nombre, String direccion, String localidad, String nombreGerente, TipoAlojamiento tipoAlojamiento, boolean privado, Integer metrosCuadrados, Integer cantHabitaciones, boolean campoDeportivo, boolean descuentosGremiales) {
        super(nombre, direccion, localidad, nombreGerente, tipoAlojamiento, privado, metrosCuadrados);
        this.cantHabitaciones = cantHabitaciones;
        this.campoDeportivo = campoDeportivo;
        this.descuentosGremiales = descuentosGremiales;
    }

    public Integer getCantHabitaciones() {
        return cantHabitaciones;
    }

    public boolean isCampoDeportivo() {
        return campoDeportivo;
    }

    public boolean isDescuentosGremiales() {
        return descuentosGremiales;
    }

    @Override
    public void crearAlojamiento() {
        super.crearAlojamiento();
        System.out.println("Indique la cantidad de habitaciones que posee la residencia:");
        this.cantHabitaciones = sc.nextInt();
        char rpta = pregunta("La residencia posee campo deportivo ? ( s/n )");
        campoDeportivo = (rpta == 'S');
        rpta = pregunta("La residencia acepta descuentos gremiales ? ( s/n )");
        campoDeportivo = (rpta == 'S');
    }

    @Override
    public void calcularPrecioHabitacion() {

    }

    @Override
    public String toString() {
        return "Residencia{" + "cantHabitaciones=" + cantHabitaciones + ", campoDeportivo=" + campoDeportivo + ", descuentosGremiales=" + descuentosGremiales + '}';
    }

    @Override
    public void mostrarDetalles() {
        super.mostrarDetalles();
        System.out.println(" ->");
        System.out.println("    * habitaciones: " + cantHabitaciones);
        System.out.println("    * posee campo deportivo: " + campoDeportivo);
        System.out.println("    * descuentos gremiales: " + descuentosGremiales);
    }
}
