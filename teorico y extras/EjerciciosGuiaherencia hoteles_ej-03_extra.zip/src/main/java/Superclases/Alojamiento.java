package Superclases;

import Enumeraciones.TipoAlojamiento;
import Interfaces.Metodos;
import java.util.Scanner;

/**
 * @author MandraKeeTo Sebastián Encina 3dProDesign Enterprise
 * creaciones3dpro@gmail.com.ar
 */
public class Alojamiento implements Metodos {

    protected String nombre;
    protected String direccion;
    protected String localidad;
    protected String nombreGerente;
    protected TipoAlojamiento tipoAlojamiento;

    protected Scanner sc = new Scanner(System.in).useDelimiter("\n");

    public Alojamiento() {
    }

    public Alojamiento(String nombre, String direccion, String localidad, String nombreGerente, TipoAlojamiento tipoAlojamiento) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.localidad = localidad;
        this.nombreGerente = nombreGerente;
        this.tipoAlojamiento = tipoAlojamiento;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getLocalidad() {
        return localidad;
    }

    public String getNombreGerente() {
        return nombreGerente;
    }

    public TipoAlojamiento getTipoAlojamiento() {
        return tipoAlojamiento;
    }

    @Override
    public void crearAlojamiento() {
        System.out.println("Ingrese el nombre del alojamiento:");
        this.nombre = sc.next();
        System.out.println("Ingrese la localidad del alojamiento:");
        this.localidad = sc.next();
        System.out.println("Ingrese la dirección del alojamiento:");
        this.direccion = sc.next();
        System.out.println("Ingrese el nombre del gerente");
        this.nombreGerente = sc.next();
    }

    @Override
    public void calcularPrecioHabitacion() {

    }
    protected char pregunta(String pregunta) {
        char rpta = 'N';
        System.out.println(pregunta);
        do {
            rpta = Character.toUpperCase(sc.next().charAt(0));
            if (rpta != 'S' && rpta != 'N') {
                System.out.println("Ingrese una opción válida !");
            }
        } while (rpta != 'S' && rpta != 'N');
        return rpta;
    }

    @Override
    public String toString() {
        return "Alojamiento{" + "nombre=" + nombre + ", direccion=" + direccion + ", localidad=" + localidad + ", nombreGerente=" + nombreGerente + ", tipoAlojamiento=" + tipoAlojamiento + ", sc=" + sc + '}';
    }

    @Override
    public void mostrarDetalles() { 
        System.out.println("Tipo: "+ tipoAlojamiento.getDescripcion() + " / Nombre: " + nombre);
        System.out.println("Dirección: " + direccion + " / Localidad: " + localidad);
        System.out.println("Nombre gerente: " + nombreGerente);
        System.out.println(" - - - - - - - - - - - - - - - - - - -");
    }

}
