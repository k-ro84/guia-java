package Superclases;

import Enumeraciones.TipoAlojamiento;

/**
 * @author MandraKeeTo Sebastián Encina 3dProDesign Enterprise
 * creaciones3dpro@gmail.com.ar
 */
public class Extrahotelero extends Alojamiento {

    protected boolean privado;
    protected Integer metrosCuadrados;

    public Extrahotelero() {
        super();
    }

    public Extrahotelero(String nombre, String direccion, String localidad, String nombreGerente, TipoAlojamiento tipoAlojamiento, boolean privado, Integer metrosCuadrados) {
        super(nombre, direccion, localidad, nombreGerente, tipoAlojamiento);
        this.privado = privado;
        this.metrosCuadrados = metrosCuadrados;
    }

    @Override
    public void crearAlojamiento() {
        super.crearAlojamiento();
        char rpta = pregunta("El alojamiento es privado ? ( s/n )");
        privado = (rpta == 'S');
        System.out.println("Indique la cantidad de metros cuadrados que posee el recinto:");
        this.metrosCuadrados = sc.nextInt();
    }

    @Override
    public void calcularPrecioHabitacion() {

    }

    @Override
    public void mostrarDetalles() {
        super.mostrarDetalles();
        System.out.println(" Alojamiento privado: " + privado + " / metros cuadrados: " + metrosCuadrados);
    }
}
