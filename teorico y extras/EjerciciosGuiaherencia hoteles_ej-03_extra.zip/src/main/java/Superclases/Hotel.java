package Superclases;

import Enumeraciones.TipoAlojamiento;

/**
 * @author MandraKeeTo Sebastián Encina 3dProDesign Enterprise
 * creaciones3dpro@gmail.com.ar
 */
public class Hotel extends Alojamiento implements Comparable<Hotel> {

    protected String categoria; // 3-4-5 estrellas !
    protected Integer cantPisosHotel;
    protected Integer cantHabitaciones;
    protected Integer cantCamasXhabitacion;
    protected Integer precioHabitacion;

    public Hotel() {
        super();
    }

    public Hotel(String nombre, String direccion, String localidad, String nombreGerente, TipoAlojamiento tipoAlojamiento, Integer cantPisosHotel, Integer cantHabitaciones, Integer cantCamasXhabitacion) {
        super(nombre, direccion, localidad, nombreGerente, tipoAlojamiento);
        this.categoria = tipoAlojamiento.getDescripcion();
        this.cantHabitaciones = cantHabitaciones;
        this.cantCamasXhabitacion = cantCamasXhabitacion;
        this.cantPisosHotel = cantPisosHotel;
    }

    public Integer getPrecioHabitacion() {
        return precioHabitacion;
    }

    public String getCategoria() {
        return categoria;
    }

    @Override
    public void crearAlojamiento() {
        super.crearAlojamiento();
        System.out.println("Ingrese la cantidad de pisos que posee el hotel:");
        this.cantPisosHotel = sc.nextInt();
        System.out.println("Ingrese la cantidad de habitaciones por piso:");
        this.cantHabitaciones = sc.nextInt();
        System.out.println("Ingrese la cantidad de camas que tiene cada habitación:");
        this.cantCamasXhabitacion = sc.nextInt();
        System.out.println("La categoría del hotel se setea automáticamente al crear el objeto:");
        this.categoria = tipoAlojamiento.getDescripcion();
        System.out.println("Categoría: " + this.categoria);
    }

    private Integer capacidadHotel() {
        Integer capacHotel = this.cantPisosHotel * this.cantHabitaciones * this.cantCamasXhabitacion;
        return capacHotel;
    }

    @Override
    public void calcularPrecioHabitacion() {
        //super.calcularPrecioHabitacion();
        this.precioHabitacion = 50 + (1 * capacidadHotel());
        System.out.println("Precio habitación: " + this.precioHabitacion);
    }

    @Override
    public int compareTo(Hotel t) { // Tiene que agregarse a la clase:  "implements Comparable<Hotel> {"
        //return this.precioHabitacion.compareTo(t.getPrecioHabitacion()); // Orden Ascendente
        return t.getPrecioHabitacion().compareTo(this.precioHabitacion); // Orden Descendente
    }

    @Override
    public String toString() {
        return "Hotel{" + "categoria=" + categoria + ", cantPisosHotel=" + cantPisosHotel + ", cantHabitaciones=" + cantHabitaciones + ", cantCamasXhabitacion=" + cantCamasXhabitacion + ", precioHabitacion=" + precioHabitacion + '}';
    }

    @Override
    public void mostrarDetalles() {
        super.mostrarDetalles();
        System.out.println("Pisos: " + cantPisosHotel + " / Hab. x piso: " + cantHabitaciones);
        System.out.println("Precio Hab: ($) " + precioHabitacion + " / camas: " + cantCamasXhabitacion);
    }
}
