package Principal;

import Servicios.ServiciosAlojamiento;
import java.io.IOException;

/**
 * @author: MandraKeeTo Sebastián Encina 3dProDesign Enterprise e-Mail:
 * creaciones3dpro@gmail.com.ar
 */
public class Main {

    public static void main(String[] args) throws IOException {

        ServiciosAlojamiento servAloj = new ServiciosAlojamiento();
    }

}
