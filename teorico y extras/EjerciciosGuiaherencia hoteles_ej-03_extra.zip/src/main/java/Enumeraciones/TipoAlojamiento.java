package Enumeraciones;

/**
 * @author MandraKeeTo
 * Sebastián Encina
 * 3dProDesign Enterprise
 * creaciones3dpro@gmail.com.ar
 */
public enum TipoAlojamiento {

    ALOJAMIENTO_H3("Hotel de 3 estrellas"),
    ALOJAMIENTO_H4("Hotel de 4 estrellas"),
    ALOJAMIENTO_H5("Hotel de 5 estrellas"),
    ALOJAMIENTO_CA("Camping"),
    ALOJAMIENTO_RE("Residencia");
    
    private String descripcion;

    private TipoAlojamiento(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return "Tipo de Alojamiento {" + descripcion + '}';
    }

    
}
