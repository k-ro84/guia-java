
//Para usar con ejemplo 3
package ExcepcionesEjemplosClase;

//
public class ExcepcionPropia extends Exception {


    public ExcepcionPropia() {
    }

 
    public ExcepcionPropia(String msg) {
        super(msg);
    }
}
