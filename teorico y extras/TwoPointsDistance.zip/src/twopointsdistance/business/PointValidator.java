/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package twopointsdistance.business;

/**
 *
 * @author andreas
 */
public class PointValidator {
    
    private PointValidator() {}
    
    private static class StaticHolder {
    
        private static PointValidator INSTANCE = new PointValidator();
        
    }
    
    public static PointValidator getInstance() {
        return StaticHolder.INSTANCE;
    }
    
    
    public boolean validate(String X, String Y) {
    
        boolean correct = true;
        
        try {
        
            double  value = Double.parseDouble(X);
                    value = Double.parseDouble(Y);
            
        }catch(NumberFormatException nfe) {
            correct = false;
        }
        
        return correct;
        
    }
    
}
