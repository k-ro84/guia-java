/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package twopointsdistance.operations;

import twopointsdistance.domain.Point;

/**
 *
 * @author andreas
 */
public class TwoPointsOperations {
    
    private TwoPointsOperations() {}
    
    private static class StaticHolder {
    
        private static TwoPointsOperations INSTANCE = new TwoPointsOperations();
        
    }
    
    public static TwoPointsOperations getInstance() {
        return StaticHolder.INSTANCE;
    }
    
    public double getDistance(Point point1, Point point2) {
    
        double result = 0f;
        
        double diffX = point2.getX()-point1.getX();
        double diffY = point2.getY()-point1.getY();
        
        double diffX2 = diffX * diffX;
        double diffY2 = diffY * diffY;
        
        double diffX2PlusdiffY2 = diffX2 + diffY2;
        
        result = Math.sqrt(diffX2PlusdiffY2);
        
        return result;
    }
    
}
